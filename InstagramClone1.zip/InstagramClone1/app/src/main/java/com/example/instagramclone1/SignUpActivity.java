package com.example.instagramclone1;

import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SignUpActivity extends AppCompatActivity {

    public static final String TAG = "SignUpActivity";
    public EditText etnUsername;
    public EditText etnPassword;
    public EditText etnEmail;
    public EditText etnPhone;

}
